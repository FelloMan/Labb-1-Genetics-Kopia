﻿using Microsoft.AspNetCore.Http;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.DependencyInjection;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Labb_1_MVC_Razor.Models
{
    public class BookShoppingCart
    {
        private readonly AppDbContext _appDbContext;
        public string BookShoppingCartId { get; set; }
        public List<BookShoppingCartItem> BookShoppingCartItems { get; set; }

        public BookShoppingCart(AppDbContext appDbContext)
        {
            _appDbContext = appDbContext;
        }

        public static BookShoppingCart GetBookCart(IServiceProvider services)
        {
            ISession session = services.GetRequiredService<IHttpContextAccessor>()?.HttpContext.Session;
            var context = services.GetService<AppDbContext>();

            string cartId = session.GetString("CartID") ?? Guid.NewGuid().ToString();
            session.SetString("CartID", cartId);

            return new BookShoppingCart(context) { BookShoppingCartId = cartId };
        }

        public void AddToBookCart(Book book, int amount)
        {
            var BookShoppingCartItem = _appDbContext.BookShoppingCartItems.SingleOrDefault(c => c.Book.BookID == book.BookID
            && c.BookShoppingCartID == BookShoppingCartId);

            if (BookShoppingCartItem == null)
            {
                BookShoppingCartItem = new BookShoppingCartItem
                {
                    BookShoppingCartID = BookShoppingCartId,
                    Book = book,
                    Amount = amount
                };
                _appDbContext.BookShoppingCartItems.Add(BookShoppingCartItem);
            }

            else
            {
                BookShoppingCartItem.Amount++;
            }
            _appDbContext.SaveChanges();
        }

        public int RemoveFromBookCart(Book book)
        {

            var BookShoppingCartItem = _appDbContext.BookShoppingCartItems.SingleOrDefault(c => c.Book.BookID == book.BookID
            && c.BookShoppingCartID == BookShoppingCartId);

            var localAmount = 0;

            if (BookShoppingCartItem != null)
            {
                if (BookShoppingCartItem.Amount > 1)
                {
                    BookShoppingCartItem.Amount--;
                    localAmount = BookShoppingCartItem.Amount;
                }
                else
                {
                    _appDbContext.BookShoppingCartItems.Remove(BookShoppingCartItem);
                }
            }
            _appDbContext.SaveChanges();
            return localAmount;


        }

        public List<BookShoppingCartItem> GetBookShoppingCartItems()
        {
            return BookShoppingCartItems ?? (BookShoppingCartItems = _appDbContext.BookShoppingCartItems.
                Where(c => c.BookShoppingCartID == BookShoppingCartId).
                Include(s => s.Book).ToList());
        }


        public void ClearBookCart()
        {
            var BookCartItems = _appDbContext.BookShoppingCartItems.Where(c => c.BookShoppingCartID == BookShoppingCartId);
            _appDbContext.BookShoppingCartItems.RemoveRange(BookCartItems);
            _appDbContext.SaveChanges();
        }

        public decimal GetBookShoppingCartTotal()
        {
            var total = _appDbContext.BookShoppingCartItems.
                Where(c => c.BookShoppingCartID == BookShoppingCartId).
                Select(c => c.Book.Price * c.Amount).
                Sum();

            return total;
        }
    }
}



