﻿using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Identity.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore;

namespace Labb_1_MVC_Razor.Models
{
    public class AppDbContext : IdentityDbContext<IdentityUser>
    {

        public AppDbContext(DbContextOptions<AppDbContext> options) : base(options)
        {

        }
        public DbSet<BookOrderDetails> BookOrderDetail { get; set; }
        public DbSet<Customer> Customers { get; set; }
        public DbSet<Book> Books { get; set; }
        public DbSet<BookOrder> BookOrders { get; set; }
        public DbSet<BookShoppingCartItem> BookShoppingCartItems { get; set; }

        //NY
        public DbSet<Transaction> Transactions { get; set; }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            base.OnModelCreating(modelBuilder);

            modelBuilder.Entity<Book>().HasData(new Book { BookID = 1, BookName = "Harry Potter", Genre = "Magi & Äventyr" });
            modelBuilder.Entity<Book>().HasData(new Book { BookID = 1, BookName = "Jaws", Genre = "Skräck & Thriller" });
            modelBuilder.Entity<Book>().HasData(new Book { BookID = 2, BookName = "Fire & Blood", Genre = "Fantasi & Äventyr" });
            modelBuilder.Entity<Book>().HasData(new Book { BookID = 2, BookName = "He Who Kills The Dragon", Genre = "Deckare" });
            modelBuilder.Entity<Book>().HasData(new Book { BookID = 3, BookName = "Pippi Longstocking", Genre = "Barn" });
            modelBuilder.Entity<Book>().HasData(new Book { BookID = 3, BookName = "Lord Of The Rings", Genre = "Fantasi & Äventyr" });
            modelBuilder.Entity<Book>().HasData(new Book { BookID = 4, BookName = "They Both Die In The End", Genre = " Lovestory " });
            modelBuilder.Entity<Book>().HasData(new Book { BookID = 4, BookName = "Gökungen", Genre = "Deckare & Thriller" });
            modelBuilder.Entity<Book>().HasData(new Book { BookID = 5, BookName = "Instats Pågår", Genre = "Biografi" });
            modelBuilder.Entity<Book>().HasData(new Book { BookID = 5, BookName = "Själsfränden", Genre = "Deckare & Spänning" });

            modelBuilder.Entity<Book>().HasData(new Book
            {
               
                BookName = "Harry Potter",
                Genre = "Magic & Adventure",
                ImageUrl = "\\Images\\harry-potter-and-the-philosopher-s-stone-3.jpg",
                ImageThumbnailUrl = "\\Images\\harry-potter-and-the-philosopher-s-stone-3.jpg",
                BookIsAvailable = true,
                BookIsNotAvailable = false,
                BookID = 1,

            });
            modelBuilder.Entity<Book>().HasData(new Book
            {

                BookName = "Jaws",
                Genre = "Horror & Thriller",
                ImageUrl = "\\Images\\jaws-1.jpg",
                ImageThumbnailUrl = "\\Images\\jaws-1.jpg",
                BookIsAvailable = true,
                BookIsNotAvailable = false,
                BookID = 1,

            });
            modelBuilder.Entity<Book>().HasData(new Book
            {

                BookName = "Fire & Blood",
                Genre = "Fantasy & Adventure",
                ImageUrl = "\\Images\\jaws-1.jpg",
                ImageThumbnailUrl = "\\Images\\jaws-1.jpg",
                BookIsAvailable = true,
                BookIsNotAvailable = false,
                BookID = 2,

            });
            modelBuilder.Entity<Book>().HasData(new Book
            {

                BookName = "He Who Kills The Dragon",
                Genre = "Crime",
                ImageUrl = "\\Images\\he-who-kills-the-dragon.jpg",
                ImageThumbnailUrl = "\\Images\\he-who-kills-the-dragon.jpg",
                BookIsAvailable = true,
                BookIsNotAvailable = false,
                BookID = 2,

            });
            modelBuilder.Entity<Book>().HasData(new Book
            {

                BookName = "Pippi Longstocking",
                Genre = "Kids",
                ImageUrl = "\\Images\\Pippi",
                ImageThumbnailUrl = "\\Images\\Pippi",
                BookIsAvailable = true,
                BookIsNotAvailable = false,
                BookID = 3,

            });
            modelBuilder.Entity<Book>().HasData(new Book
            {

                BookName = "They Both Die In The End",
                Genre = "Lovestory",
                ImageUrl = "\\Images\\Both.Die.jpg",
                ImageThumbnailUrl = "\\Images\\Both.Die.jpg",
                BookIsAvailable = true,
                BookIsNotAvailable = false,
                BookID = 3,

            });
            modelBuilder.Entity<Book>().HasData(new Book
            {

               BookName = "Lord Of The Rings",
               Genre = "Fantasy & Adventure",
               ImageUrl = "\\Images\\Lord-of-the-rings.jpg",
               ImageThumbnailUrl = "\\Images\\Lord-of-the-rings.jpg",
               BookIsAvailable = true,
               BookIsNotAvailable = false,
               BookID = 4,

            });
            modelBuilder.Entity<Book>().HasData(new Book
            {

               BookName = "Gökungen",
               Genre = "Crime & Thriller",
               ImageUrl = "\\Images\\Gokungen.jpg",
               ImageThumbnailUrl = "\\Images\\Gokungen.jpg",
               BookIsAvailable = true,
               BookIsNotAvailable = false,
               BookID = 4,

            });
            modelBuilder.Entity<Book>().HasData(new Book
            {

                BookName = "Insats Pågår",
                Genre = "Biografi",
                ImageUrl = "\\Images\\InsatsPågår.jpg",
                ImageThumbnailUrl = "\\Images\\InsatsPågår.jpg",
                BookIsAvailable = true,
                BookIsNotAvailable = false,
                BookID = 5,

            });
            modelBuilder.Entity<Book>().HasData(new Book
            {

                BookName = "Själsfränden",
                Genre = "Deckare & Spänning",
                ImageUrl = "\\Images\\Själsfränden.jpg",
                ImageThumbnailUrl = "\\Images\\Själsfränden.jpg",
                BookIsAvailable = true,
                BookIsNotAvailable = false,
                BookID = 5,

            });


        }
    } 
}
