﻿using System.ComponentModel.DataAnnotations;

namespace Labb_1_MVC_Razor.Models
{
    public class BookShoppingCartItem
    {

        public int BookShoppingCartItemID { get; set; }
        public string BookShoppingCartID { get; set; }
        public Book Book { get; set; }
        public int Amount { get; set; }
    }
}
