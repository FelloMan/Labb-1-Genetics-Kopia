﻿namespace Labb_1_MVC_Razor.Models
{
    public interface IBookRepository
    {
        IEnumerable<Book> GetAllBook { get; }
        Book GetBookById(int BookID);
    }
}
