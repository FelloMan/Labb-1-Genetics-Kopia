﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Labb_1_MVC_Razor.Models
{
    public class Customer
    {
        public int CustomerID { get; set; }
        public string CustomerName { get; set; }
        public string CustomerAdress { get; set; }

        [ForeignKey("Book")]
        public int Bookid { get; set; }
        public  Book Book { get; set; }

    }
}


// 1.Customer
// 2.Book
