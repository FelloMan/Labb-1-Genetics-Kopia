﻿namespace Labb_1_MVC_Razor.Models
{
    public interface ICustomerRepository
    {
        IEnumerable<Customer> GetAllCustomer { get; }
       
        Customer GetCustomerByID(int customerid);
    }
}
