﻿using Microsoft.EntityFrameworkCore;

namespace Labb_1_MVC_Razor.Models
{

    public class BookRepository : IBookRepository
    {
        private readonly AppDbContext _appDbContext;

        public BookRepository(AppDbContext appDbContext)
        {
            _appDbContext = appDbContext;
        }

        public IEnumerable<Book> GetAllBook
        {
            get 
            {
                return _appDbContext.Books.Include(c => c.Customer);
            }
        }

        public Book GetBookById(int bookId)
        {
            return _appDbContext.Books.FirstOrDefault(c => c.BookID == bookId);
        }
     

    }
    
}



