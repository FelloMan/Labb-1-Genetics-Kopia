﻿using Microsoft.AspNetCore.Mvc.ModelBinding;
using System.ComponentModel.DataAnnotations;
namespace Labb_1_MVC_Razor.Models
{
    public class BookOrder
    {
        public int BookOrderID { get; set; }

        [Required(ErrorMessage = "Please enter a valid name")]
        [Display(Name = "First Name")]
        [StringLength(25)]
        public string CustomerName { get; set; }      

        [Required(ErrorMessage = "Please enter a valid Adress")]
        [Display(Name = " Street Adress")]
        [StringLength(100)]
        public string Address { get; set; }

        [Required(ErrorMessage = "Please enter a valid Phone Number")]
        [Display(Name = " Phone Number")]
        [DataType(DataType.PhoneNumber)]
        public string Phone { get; set; }
        public decimal OrderTotal { get; set; }
        [BindNever]
        public DateTime OrderPlaced { get; set; }


    }
}
