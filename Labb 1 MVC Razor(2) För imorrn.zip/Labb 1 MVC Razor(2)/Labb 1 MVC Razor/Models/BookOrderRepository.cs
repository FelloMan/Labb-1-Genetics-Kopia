﻿namespace Labb_1_MVC_Razor.Models
{
    public class BookOrderRepository : IBookOrderRepository
    {
        private readonly AppDbContext _appDbContext;
        private readonly BookShoppingCart _bookShoppingCart;

        public BookOrderRepository(AppDbContext appDbContext, BookShoppingCart bookShoppingCart)
        {
            _appDbContext = appDbContext;
        }

        public void CreateBookOrder (BookOrder bookorder)
        {
            bookorder.OrderPlaced = DateTime.Now;
            bookorder.OrderTotal = _bookShoppingCart.GetBookShoppingCartTotal();
            _appDbContext.BookOrders.Add(bookorder);
            _appDbContext.SaveChanges();

            var bookShoppingCartItems = _bookShoppingCart.GetBookShoppingCartItems();
            
            foreach (var bookshoppingCartItem in bookShoppingCartItems)
            {
                var bookOrderDetail = new BookOrderDetails
                {
                    Amount = bookshoppingCartItem.Amount,
                    Price = bookshoppingCartItem.Book.Price,
                    BookID = bookshoppingCartItem.Book.BookID,
                    BookOrderID = bookorder.BookOrderID,
                };

                _appDbContext.BookOrderDetail.Add(bookOrderDetail);
            }
            _appDbContext.SaveChanges();
        }
    }
}
