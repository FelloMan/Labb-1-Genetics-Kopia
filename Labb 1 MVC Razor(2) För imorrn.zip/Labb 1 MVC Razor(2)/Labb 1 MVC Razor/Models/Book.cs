﻿using System.ComponentModel.DataAnnotations.Schema;
namespace Labb_1_MVC_Razor.Models
{
    public class Book
    {
        public int BookID { get; set; }
        public string BookName { get; set; }
        public string Genre { get; set; }
        public int Year { get; set; }
        //Tillfälligt
        //////////////
        public decimal Price { get; set; }
        //Tillfälligt
        //////////////
        public bool BookIsAvailable { get; set; }
        public bool BookIsNotAvailable { get; set; }    
        public string? ImageUrl { get; set; }
        public string? ImageThumbnailUrl { get; set; }

        [ForeignKey("Customer")]
        public int Customerid { get; set; }
        public Customer Customer { get; set; }
       


    }
}