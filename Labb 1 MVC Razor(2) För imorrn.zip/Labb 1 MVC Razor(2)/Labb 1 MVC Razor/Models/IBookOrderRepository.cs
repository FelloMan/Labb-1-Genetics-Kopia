﻿namespace Labb_1_MVC_Razor.Models
{
    public interface IBookOrderRepository 
    {
        
        void CreateBookOrder(BookOrder bookorder);
        
    }
}
