﻿using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Labb_1_MVC_Razor.Models
{
    public class Transaction
    {
        [Key]
        public int TransactionID { get; set; }

        [Column(TypeName = "nvarchar(12)")]
        [Display(Name = "Account Number")]
        [Required(ErrorMessage = "This field is required!!")]
        [MaxLength(12, ErrorMessage = "Maximum 12 characters only")]
        public string AccountNumber { get; set; }
        [Column(TypeName = "nvarchar(100)")]
        [Display(Name = "Holder Name")]
        [Required(ErrorMessage = "This field is required!!")]
        public string HolderName { get; set; }
        [Column(TypeName = "nvarchar(50)")]
        [Display(Name = "Bank Name")]
        [Required(ErrorMessage = "This field is required!!")]
        public string BankName { get; set; }
        [Column(TypeName = "nvarchar(11)")]
        [Display(Name = "SWIFT Code")]
        [Required(ErrorMessage = "This field is required!!")]
        [MaxLength(11, ErrorMessage = "Maximum 11 characters only")]

        public string SWIFTCode { get; set; }
        [Required(ErrorMessage = "This field is required!!")]
        public int Amount { get; set; }

        [DisplayFormat(DataFormatString = "{0:MM-DD-YY}")]
        public DateTime Date { get; set; }


    }
}
