﻿using Microsoft.EntityFrameworkCore;

namespace Labb_1_MVC_Razor.Models

{
    public class CustomerRepository : ICustomerRepository
    {
        private readonly AppDbContext _appDbContext;

        public CustomerRepository(AppDbContext appDbContext)
        {
            _appDbContext = appDbContext;
        }

        public IEnumerable<Customer> GetAllCustomer => _appDbContext.Customers;
        

        public Customer GetCustomerByID(int customerID)
        {
            return _appDbContext.Customers.FirstOrDefault(c => c.CustomerID == customerID);
        }
        
    }
        
} 

