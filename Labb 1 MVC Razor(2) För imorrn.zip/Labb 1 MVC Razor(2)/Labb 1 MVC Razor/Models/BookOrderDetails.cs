﻿namespace Labb_1_MVC_Razor.Models
{
    public class BookOrderDetails
    {

        public int BookOrderDetailsID { get; set; }
        public int BookOrderID { get; set; }
        public BookOrder BookOrder { get; set; }     
        
        public Book Book { get; set; }
        public int BookID { get; set; }

        public int Amount { get; set; }
        public decimal Price { get; set; }

    }
}
