﻿using Labb_1_MVC_Razor.Models;
using Labb_1_MVC_Razor.ViewModels;
using Microsoft.AspNetCore.Mvc;
namespace Labb_1_MVC_Razor.Components
{
    public class ShoppingCartSummary : ViewComponent
    {
        private readonly BookShoppingCart _bookshoppingCart;

        public ShoppingCartSummary(BookShoppingCart bookshoppingCart)
        {
            _bookshoppingCart = bookshoppingCart;
        }


        public IViewComponentResult Invoke()
        {
            _bookshoppingCart.BookShoppingCartItems = _bookshoppingCart.GetBookShoppingCartItems();

            var bookShoppingCartViewModel = new BookShoppingCartViewModel
            {
                BookShoppingCart = _bookshoppingCart,
                BookShoppingCartTotal = _bookshoppingCart.GetBookShoppingCartTotal()
            };

            return View(bookShoppingCartViewModel);
        }
    }
}
