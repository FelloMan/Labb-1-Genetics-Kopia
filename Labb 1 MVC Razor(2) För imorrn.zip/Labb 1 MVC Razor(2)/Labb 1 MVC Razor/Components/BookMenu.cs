﻿using Labb_1_MVC_Razor.Models;
using Microsoft.AspNetCore.Mvc;
namespace Labb_1_MVC_Razor.Components;

public class BookMenu : ViewComponent
{
    private readonly ICustomerRepository _customerRepository;


    public BookMenu(ICustomerRepository customerRepository)
    {
        _customerRepository = customerRepository;
    }
    public IViewComponentResult Invoke()
    {
        var customers = _customerRepository.GetAllCustomer.OrderBy(c => c.CustomerName);

        return View(customers);
    }
} 
