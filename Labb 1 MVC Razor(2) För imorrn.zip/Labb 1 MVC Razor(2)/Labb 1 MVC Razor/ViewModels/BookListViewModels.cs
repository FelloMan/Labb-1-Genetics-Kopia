﻿using Labb_1_MVC_Razor.Models;

namespace Labb_1_MVC_Razor.ViewModels
{
    public class BookListViewModels
    {
        public IEnumerable<Book> Books { get; set; }

        public string CurrentCustomer { get; set; }
    }
}
