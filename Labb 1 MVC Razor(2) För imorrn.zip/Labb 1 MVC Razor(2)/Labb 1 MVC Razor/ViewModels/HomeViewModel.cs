﻿using Labb_1_MVC_Razor.Models;

namespace Labb_1_MVC_Razor.ViewModels
{
    public class HomeViewModel
    {
        public IEnumerable<Book> BookIsAvailable { get; set; }
    }
}
