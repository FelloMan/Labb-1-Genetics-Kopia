﻿using Labb_1_MVC_Razor.Models;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace Labb_1_MVC_Razor.Controllers
{
    public class BookOrderController : Controller
    {
        private readonly IBookOrderRepository _bookOrderRepository;
        private readonly BookShoppingCart _bookshoppingCart;


        public BookOrderController (IBookOrderRepository bookOrderRepository, BookShoppingCart bookshoppingCart)
        {
            _bookOrderRepository = bookOrderRepository;
            _bookshoppingCart = bookshoppingCart;
        }

        public IActionResult Checkout()
        {
            return View();
        }

        [HttpPost]

        public IActionResult CheckOut(BookOrder bookorder)
        {
            _bookshoppingCart.BookShoppingCartItems = _bookshoppingCart.GetBookShoppingCartItems();

            if(_bookshoppingCart.BookShoppingCartItems.Count == 0)
            {
                ModelState.AddModelError("", "Your Cart Is Empty");
            }

            if (ModelState.IsValid)
            {
                _bookOrderRepository.CreateBookOrder(bookorder);
                _bookshoppingCart.ClearBookCart();

                return RedirectToAction("CheckoutComplete");
            }

            return View(bookorder);
        }

        public IActionResult CheckoutComplete()
        {
            ViewBag.CheckoutCompleteMessage = "Thank you for your Order";
            return View();
        }
    }
}
