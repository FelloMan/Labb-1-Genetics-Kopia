﻿namespace Labb_1_MVC_Razor.Controllers
{
    public class CustomerController
    {

    }
}
