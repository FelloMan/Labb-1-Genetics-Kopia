﻿using Labb_1_MVC_Razor.Models;
using Labb_1_MVC_Razor.ViewModels;
using Microsoft.AspNetCore.Mvc;

namespace Labb_1_MVC_Razor.Controllers
{
    public class BookShoppingCartController : Controller
    {

        private readonly IBookRepository _bookRepository;
        private readonly BookShoppingCart _bookshoppingCart;

        public BookShoppingCartController(IBookRepository bookRepository , BookShoppingCart bookShoppingCart)
        {
            _bookRepository = bookRepository;
            _bookshoppingCart = bookShoppingCart;
        }

        public IActionResult Index()
        {
            _bookshoppingCart.BookShoppingCartItems = _bookshoppingCart.GetBookShoppingCartItems();
            var bookshoppingCartViewModel = new BookShoppingCartViewModel
            {
                BookShoppingCart = _bookshoppingCart,
                BookShoppingCartTotal = _bookshoppingCart.GetBookShoppingCartTotal(),
            };

            return View(bookshoppingCartViewModel);
        }

        public RedirectToActionResult AddToBookShoppingCart (int bookId)
        {
            var addedBook = _bookRepository.GetAllBook.FirstOrDefault(c => c.BookID == bookId);
            if (addedBook != null)
            {
                _bookshoppingCart.AddToBookCart(addedBook, 1);
            }
            return RedirectToAction("Index");
        }


        public RedirectToActionResult RemoveFromBookShoppingCart(int bookId)
        {
            var selectedBook = _bookRepository.GetAllBook.FirstOrDefault(c => c.BookID == bookId);

            if(selectedBook != null)
            {
                _bookshoppingCart.RemoveFromBookCart(selectedBook);
            }
            return RedirectToAction("Index");
        }

        public RedirectToActionResult ClearBookCart()
        {
            _bookshoppingCart.ClearBookCart();
            return RedirectToAction("Index");
        }

    }


}
