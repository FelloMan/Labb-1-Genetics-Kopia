﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Labb_1_MVC_Razor.Models;

namespace Labb_1_MVC_Razor.Controllers
{
    public class TransactionController : Controller
    {
        private readonly AppDbContext _context;

        public TransactionController(AppDbContext context)
        {
            _context = context;
        }

        public async Task<IActionResult> Index()
        {
            return View(await _context.Transactions.ToListAsync());
        }



        // Get Transaction/AddOrEdit

        public IActionResult AddOrEdit(int id)
        {
            if (id == 0)
            {
                return View(new Transaction());
            }
            else
            {
                return View(_context.Transactions.Find(id));
            }
        }




        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> AddOrEdit([Bind("TransactionID, AccountNumber, HolderName, BankName, SWIFTCode, Amount, Date ")] Transaction transaction)
        {
            if (ModelState.IsValid)
            {
                if (transaction.TransactionID == 0)
                {
                    transaction.Date = DateTime.Now;
                    _context.Add(transaction);
                    await _context.SaveChangesAsync();

                }
                else
                {
                    _context.Update(transaction);

                }
                await _context.SaveChangesAsync();
                return RedirectToAction(nameof(Index));


            }
            return View(transaction);
        }


        //Post : Transaction/Delete

        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(int id)
        {
            var transactionToDelete = await _context.Transactions.FindAsync(id);
            _context.Transactions.Remove(transactionToDelete);
            await _context.SaveChangesAsync();
            return RedirectToAction(nameof(Index));
        }



    }
}
