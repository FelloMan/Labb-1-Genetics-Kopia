﻿using Labb_1_MVC_Razor.Models;
using Labb_1_MVC_Razor.Controllers;
using Microsoft.AspNetCore.Mvc;
using Labb_1_MVC_Razor.ViewModels;

namespace Labb_1_MVC_Razor.Controllers
{
    public class BookController : Controller
    {
        private readonly IBookRepository _bookRepository;
        private readonly ICustomerRepository _customerRepository;


        public BookController(IBookRepository bookRepository, ICustomerRepository customerRepository)
        {
            _bookRepository = bookRepository;
            _customerRepository = customerRepository;

        }

        public ViewResult List(string customer)
        {

            IEnumerable<Book> books;
            string currentCustomer;

            if (string.IsNullOrEmpty(customer))
            {
                books = _bookRepository.GetAllBook.OrderBy(c => c.BookID);
                currentCustomer = "All Books";
            }
            else
            {
                books = _bookRepository.GetAllBook.Where(c => c.Customer.CustomerName == customer);

                currentCustomer = _customerRepository.GetAllCustomer.FirstOrDefault(c => c.CustomerName == customer)?.CustomerName;
            }

            return View(new BookListViewModels
            {
                Books = books,
                CurrentCustomer = currentCustomer

            });
        }

        public IActionResult Details(int ID)
        {
            var book = _bookRepository.GetBookById(ID);
            if(book == null)
            {
                return NotFound();
            }
            return View(book);
        }
    } 
}
